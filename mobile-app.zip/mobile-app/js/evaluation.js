$(document).ready(function(){
	
});
(function($){
	$(window).load(function(){
		$(".mrk-height, .answer-picture").mCustomScrollbar({
			axis:"yx",
			scrollbarPosition:"inside"
		});
	});
})(jQuery);