$(document).ready(function(){
	var logo_height = $(".logo-container").innerHeight();
	var topbar_height = $(".top-bar").innerHeight();
	var search_height = $(".search").innerHeight();
	var win_height = $(window).innerHeight();
	var nav_height = (win_height - logo_height) - 25;
	var right_panel = (win_height - topbar_height) - 2;
	
	
    $(".left-container .menuIcon").click(function(){
        $(".left-container").toggleClass("hide-menu");
        $(".left-container, .right-container").toggleClass("show-menu");
		$("nav ul li ul").css("display","none");
        if($(".show-menu").length > 0){
            $(".left-container.show-menu").animate({width: "290px"}, 50, 'linear');
        }else{
            $(".left-container").animate({width: "72px"}, 50, 'linear');
        }
		if(topbar_height > logo_height){
			$(".logo-container").css("height",$(".top-bar").innerHeight());
			$(".right-container").css({"min-height":right_panel, "margin-top":$(".top-bar").innerHeight()});
		}else{
			$(".top-bar").css("height",$(".logo-container").innerHeight());
			$(".right-container").css({"min-height":right_panel, "margin-top":$(".logo-container").innerHeight()});
		}
    });
	
	$(".hide-menu nav > ul:first-child li").children("div").hover(function(){
		var hover_menu_top = $(this).parent("li").offset().top;
		if($(".hide-menu").length > 0){
			$(".hide-menu ul li ul").css("top", hover_menu_top+"px");
		}
	});
    $("nav ul li ul").slideUp();
   
    $("nav ul li div").click(function(){
        if($(".show-menu").length > 0){
            $(this).parent("li").siblings("li").children("ul").slideUp();
            $(this).children(".down-arrow").toggleClass("up-arrow");
            $(this).parent("li").siblings("li").children("div").children(".down-arrow").removeClass("up-arrow");
            $(this).parent("li").children("ul").slideToggle();
        }
    });

	if(topbar_height > logo_height){
		$(".logo-container").css("height",$(".top-bar").innerHeight());
		$(".right-container").css({"min-height":right_panel, "margin-top":$(".top-bar").innerHeight()});
	}else{
		$(".top-bar").css("height",$(".logo-container").innerHeight());
		$(".right-container").css({"min-height":right_panel, "margin-top":$(".logo-container").innerHeight()});
	}
	
	$('[data-toggle="tooltip"]').tooltip();   

	/* Navigation Height Starts Here */
	$("nav").css("height", nav_height+"px");
	/* Navigation Height Ends Here */
	
	/* Table Header Collapse Code Starts Here */
	$(".mark-panel table tr.header").click(function(){
		$(this).toggleClass("isClose");
		$(this).next("tr").slideToggle("slow");
	});
	/* Table Header Collapse Ends Here  */
	
	/* Evaluation Height Calculation Starts Here */
	var ad_option_h = $(".advance-option").innerHeight() + 20;
	var panel_ex_frame = right_panel - ad_option_h;
	var panel_ex_mark = right_panel - (ad_option_h - 10);
	var fame_h = panel_ex_frame  -  ($(".tools-panel").innerHeight() * 2);
	var mark_h = panel_ex_mark  -  ($(".tools-panel").innerHeight() + ($(".mark-panel thead").innerHeight()*2));

	$(".answer-picture").css("height", fame_h + "px");
	$(".mark-panel td div.mrk-height").css("height", mark_h + "px");
	/* Evaluation Height Calculation Ends Here */
	
	
	$(window).on("resize", function () {
		logo_height = $(".logo-container").innerHeight();
		topbar_height = $(".top-bar").innerHeight();
		search_height = $(".search").innerHeight();
		win_height = $(window).innerHeight();
		nav_height = (win_height - logo_height) - 25;
		right_panel = (win_height - topbar_height) - 2;

		if(topbar_height > logo_height){
			$(".logo-container").css("height",$(".top-bar").innerHeight());
			$(".right-container").css({"min-height":right_panel, "margin-top":$(".top-bar").innerHeight()});
		}else{
			$(".top-bar").css("height",$(".logo-container").innerHeight());
			$(".right-container").css({"min-height":right_panel, "margin-top":$(".logo-container").innerHeight()});
		}
		
		$("nav").css("height", nav_height+"px");
	
		$(".right-container").css("min-height", right_panel);
		
		/* Evaluation Height Calculation Starts Here */
		ad_option_h = $(".advance-option").innerHeight() + 20;
		panel_ex_frame = right_panel - ad_option_h;
		panel_ex_mark = right_panel - (ad_option_h - 10);
		fame_h = panel_ex_frame  -  ($(".tools-panel").innerHeight() * 2);
		mark_h = panel_ex_mark  -  ($(".tools-panel").innerHeight() + ($(".mark-panel thead").innerHeight()*2));

		$(".answer-picture").css("height", fame_h + "px");
		$(".mark-panel td div.mrk-height").css("height", mark_h + "px");
		/* Evaluation Height Calculation Ends Here */
	});
});


/* Scroll Bar Code */
(function($){
	$(window).load(function(){
		$(".mrk-height, .answer-picture").mCustomScrollbar({
			axis:"yx",
			scrollbarPosition:"inside"
		});
	});
})(jQuery);
/* Scroll Bar Code */